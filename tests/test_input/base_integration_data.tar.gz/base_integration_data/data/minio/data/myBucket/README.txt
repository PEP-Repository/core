This bucket is used by the storage facility.
