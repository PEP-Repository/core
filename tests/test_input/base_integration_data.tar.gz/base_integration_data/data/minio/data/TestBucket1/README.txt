This bucket is used by storagefacility/pepStorageFacilityUnitTests
